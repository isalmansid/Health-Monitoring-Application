import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Plot from 'react-plotly.js';
import './Chatbot.css'; // Import your custom CSS file

function Chatbot() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([
    {
      id: 0,
      text: "Please try typing full sentences as I am still learning!",
      sender: "bot"
    },
    {
      id: 1,
      text: "I am your Health assistant.",
      sender: "bot"
    },
    {
      id: 2,
      text: "Hi there! How can I help you? What symptoms are you facing?",
      sender: "bot"
    }
  ]);
  const [sentimentData, setSentimentData] = useState([]);
  const [showGraph, setShowGraph] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;
    try {
      const response = await axios.post('http://localhost:5000/get', { message: input });
      const responseData = response.data;
      setMessages([...messages, { text: input, sender: 'user' }, { text: responseData.response, sender: 'bot' }]);
      setSentimentData([...sentimentData, ...responseData.sentiment]);
      setInput('');
    } catch (error) {
      console.error('Error fetching bot response:', error);
    }
  };

  const generateGraph = () => {
    // Plot sentiment data using Plotly.js
    if (sentimentData.length > 0) {
      const xData = Array.from({ length: sentimentData.length }, (_, i) => i + 1);
      const yData = sentimentData;

      return (
        <Plot
          data={[
            {
              type: 'scatter',
              x: xData,
              y: yData,
              mode: 'lines+markers',
              marker: { color: 'blue' },
            },
          ]}
          layout={{
            width: 600,
            height: 400,
            title: 'Healthcare Analysis',
            xaxis: {
              title: 'Message Number',
            },
            yaxis: {
              title: 'Healthcare Score',
            },
          }}
        />
      );
    } else {
      return null; // Return null if sentimentData is empty
    }
  };

  useEffect(() => {
    const chatContainer = document.querySelector('.chat-container');
    chatContainer.scrollTop = chatContainer.scrollHeight;
  }, [messages]);

  return (
    <div className="container d-flex justify-content-center align-items-center vh-100">
      <div className="col-md-8">
        <div className="chat-container">
          <div className="chatbox">
            {messages.map((message, index) => (
              <div key={index} className={`message ${message.sender}`}>
                <p>{message.text}</p>
              </div>
            ))}
          </div>
          <div className="userInput">
            <input
              id="textInput"
              type="text"
              name="msg"
              placeholder="Type your message here..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyPress={e => {
                if (e.key === 'Enter') sendMessage();
              }}
            />
            <button
              id="buttonInput"
              className="btn btn-primary"
              onClick={sendMessage}
            >
              Send
            </button>
            <button
              id="monitorHealthButton"
              className="btn btn-success"
              onClick={() => setShowGraph(true)}
            >
              Monitor Health
            </button>
          </div>
        </div>
        <div className="mt-4">
          {showGraph && generateGraph()}
        </div>
      </div>
    </div>
  );
}

export default Chatbot;